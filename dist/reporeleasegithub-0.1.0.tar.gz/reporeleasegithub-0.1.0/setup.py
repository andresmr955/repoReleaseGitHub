from setuptools import setup, find_packages

setup(
    name="repoReleaseGitHub",                           # Nombre del paquete
    version="0.1.0",                                # Versión inicial
    packages=find_packages(),                       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="Andres Marquez",                         # Tu nombre
    author_email="andresmr955@gmail.com",                 # Tu correo electrónico
    url="https://github.com/andresmr955/repoReleaseGitHub",     # URL del proyecto
)
